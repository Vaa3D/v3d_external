mex nrrdLoad.c -I/projects/lmi/people/gk/teem/include -L/projects/lmi/people/gk/teem/solaris/lib -lteem -lz -lm
mex nrrdLoadOrientation.c -I/projects/lmi/people/gk/teem/include -L/projects/lmi/people/gk/teem/solaris/lib -lteem -lz -lm
mex nrrdSave.c -I/projects/lmi/people/gk/teem/include -L/projects/lmi/people/gk/teem/solaris/lib -lteem -lz -lm
